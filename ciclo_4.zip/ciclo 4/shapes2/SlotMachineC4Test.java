import static org.junit.Assert.*;
import java.util.ArrayList;
import java.util.Arrays;
import org.junit.Before;
import org.junit.Test;

/**
 * Pruebas de unidad del ciclo 4: tipos de ruedas y de simbolos.
 * Todas en modo invisible.
 *
 * @author  (RodriguezH - SarmientoM)
 * @version (ciclo 4)
 */
public class SlotMachineC4Test
{
    private SlotMachine machine;

    /**
     * Maquina sin ruedas con los simbolos normales red, blue, yellow.
     */
    @Before
    public void setUp() {
        machine = new SlotMachine();
        machine.addSymbol(1, "red");
        machine.addSymbol(2, "blue");
        machine.addSymbol(3, "yellow");
    }

    /*
     * Crea una rueda normal con los colores y tipos dados.
     */
    private Wheel rueda(String[] colores, String[] tipos) {
        return new Wheel(new ArrayList<String>(Arrays.asList(colores)),
                         new ArrayList<String>(Arrays.asList(tipos)));
    }

    // ---------------- tipos de rueda ----------------

    @Test
    public void shouldAddWheelsOfEveryType() {
        machine.addWheel("normal", 1);
        machine.addWheel("lefty", 2);
        machine.addWheel("rebel", 3);
        machine.addWheel("lazy", 4);
        assertEquals(4, machine.configuration().length);
    }

    @Test
    public void shouldNotAddWheelOfUnknownType() {
        machine.addWheel("crazy", 1);
        assertEquals(0, machine.configuration().length);
    }

    // ---------------- rebel ----------------

    @Test
    public void shouldNotLockRebel() {
        machine.addWheel("rebel", 1);
        machine.look(1);
        machine.spin(1, 1);
        assertEquals("blue", machine.configuration()[0]);
    }

    @Test
    public void shouldLockNormalWheel() {
        machine.addWheel("normal", 1);
        machine.look(1);
        machine.spin(1, 1);
        assertEquals("red", machine.configuration()[0]);
    }

    @Test
    public void shouldNotDeleteRebel() {
        machine.addWheel("normal", 1);
        machine.addWheel("rebel", 2);
        machine.delWheel(1);          // delWheel usa la posicion desde 0: apunta a la rebel
        assertEquals(2, machine.configuration().length);
    }

    @Test
    public void shouldNotSwapRebel() {
        machine.addWheel("normal", 1);
        machine.addWheel("rebel", 2);
        machine.spin(1, 1);
        machine.swap(1, 2);
        assertArrayEquals(new String[]{"blue", "red"}, machine.configuration());
    }

    // ---------------- lefty ----------------

    @Test
    public void shouldCopyLeftWheelWhenLeftySpins() {
        machine.addWheel("normal", 1);
        machine.addWheel("lefty", 2);
        machine.spin(1, 2);
        machine.spin(2, 1);
        assertEquals("yellow", machine.configuration()[1]);
    }

    @Test
    public void shouldSpinNormallyWhenLeftyIsFirst() {
        machine.addWheel("lefty", 1);
        machine.spin(1, 1);
        assertEquals("blue", machine.configuration()[0]);
    }

    @Test
    public void shouldCopyLeftWheelWhenSpinningAll() {
        machine.addWheel("normal", 1);
        machine.addWheel("lefty", 2);
        for (int i = 0; i < 10; i++) {
            machine.spin();
            assertEquals(machine.configuration()[0], machine.configuration()[1]);
        }
    }

    // ---------------- lazy (propuesto) ----------------

    @Test
    public void shouldSpinHalfTheStepsLazy() {
        machine.addWheel("lazy", 1);
        machine.spin(1, 2);
        assertEquals("blue", machine.configuration()[0]);
    }

    @Test
    public void shouldNotMoveLazyWithOneStep() {
        machine.addWheel("lazy", 1);
        machine.spin(1, 1);
        assertEquals("red", machine.configuration()[0]);
    }

    // ---------------- tipos de simbolo ----------------

    @Test
    public void shouldAddSymbolsOfEveryType() {
        machine.addSymbol("ephemeral", 4, "green");
        machine.addSymbol("shy", 5, "magenta");
        assertEquals(5, machine.symbols().length);
    }

    @Test
    public void shouldNotAddSymbolOfUnknownType() {
        machine.addSymbol("crazy", 4, "green");
        assertEquals(3, machine.symbols().length);
    }

    // ---------------- ephemeral ----------------

    @Test
    public void shouldShrinkEphemeralWhenWheelSpins() {
        Wheel w = rueda(new String[]{"red", "blue"}, new String[]{"ephemeral", "normal"});
        w.Spin(1);
        w.Spin(1);                    // vuelve al efimero despues de dos giros
        assertEquals(Symbol.SIZE - 2 * Ephemeral.STEP, w.getVisibleSymbol().getSize());
    }

    @Test
    public void shouldNotShrinkEphemeralBelowAPoint() {
        Symbol e = new Ephemeral("red");
        for (int i = 0; i < 50; i++) {
            e.spun();
        }
        assertEquals(Ephemeral.MIN_SIZE, e.getSize());
    }

    @Test
    public void shouldNotShrinkNormalSymbol() {
        Wheel w = rueda(new String[]{"red", "blue"}, new String[]{"normal", "normal"});
        w.Spin(1);
        w.Spin(1);
        assertEquals(Symbol.SIZE, w.getVisibleSymbol().getSize());
    }

    // ---------------- shy ----------------

    @Test
    public void shouldHideShyWhenSelected() {
        Wheel w = rueda(new String[]{"red", "blue"}, new String[]{"normal", "shy"});
        w.Spin(1);
        assertFalse(w.getVisibleSymbol().isVisible());
    }

    @Test
    public void shouldShowShyWhenSelectedAgain() {
        Wheel w = rueda(new String[]{"red", "blue"}, new String[]{"normal", "shy"});
        w.Spin(1);
        w.Spin(1);
        w.Spin(1);
        assertTrue(w.getVisibleSymbol().isVisible());
    }

    @Test
    public void shouldNotHideShyFromConfiguration() {
        machine.addSymbol("shy", 4, "green");
        machine.addWheel(1);
        machine.placeSymbol(1, "green");
        assertEquals("green", machine.configuration()[0]);
    }

    // ---------------- el solver sigue funcionando ----------------

    @Test
    public void shouldStillSolveWithNormalMachine() {
        int[][] acciones = SlotMachineContest.solve(5);
        assertTrue(acciones.length <= 2 * 5 * 5 + 5 + 1);
    }
}
