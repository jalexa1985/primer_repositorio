import static org.junit.Assert.*;
import javax.swing.JOptionPane;
import org.junit.Test;

/**
 * Pruebas de aceptacion del ciclo 4 para la presentacion (modo visible).
 * El usuario observa la maquina y confirma si se ve correctamente.
 *
 * @author  (RodriguezH - SarmientoM)
 * @version (ciclo 4)
 */
public class SlotMachineC4AcceptanceTest
{
    /**
     * Una rueda de cada tipo: normal (sin barra), lefty (barra azul),
     * rebel (barra roja) y lazy (barra naranja). La lefty copia a la normal.
     */
    @Test
    public void shouldShowEveryWheelType() {
        SlotMachine machine = new SlotMachine();
        machine.addSymbol(1, "red");
        machine.addSymbol(2, "blue");
        machine.addSymbol(3, "yellow");
        machine.makeVisible();
        machine.addWheel("normal", 1);
        machine.addWheel("lefty", 2);
        machine.addWheel("rebel", 3);
        machine.addWheel("lazy", 4);
        machine.spin(1, 2);
        machine.spin(2, 1);
        int respuesta = JOptionPane.showConfirmDialog(null,
            "¿Ves 4 ruedas: la 1 sin barra, la 2 con barra azul y el mismo color que la 1,"
            + " la 3 con barra roja y la 4 con barra naranja?");
        machine.makeInvisible();
        assertEquals(JOptionPane.YES_OPTION, respuesta);
    }

    /**
     * Simbolos efimero (marca blanca, se encoge) y timido (marca negra,
     * aparece y desaparece cada vez que queda seleccionado).
     */
    @Test
    public void shouldShowEverySymbolType() {
        SlotMachine machine = new SlotMachine();
        machine.addSymbol("ephemeral", 1, "red");
        machine.addSymbol("shy", 2, "blue");
        machine.makeVisible();
        machine.addWheel(1);
        machine.addWheel(2);
        machine.spin(2, 1);
        for (int i = 0; i < 4; i++) {
            machine.spin(1, 2);
        }
        int respuesta = JOptionPane.showConfirmDialog(null,
            "¿La rueda 1 muestra un circulo rojo mas pequeno y la rueda 2 quedo vacia"
            + " (el simbolo azul timido se escondio)?");
        machine.makeInvisible();
        assertEquals(JOptionPane.YES_OPTION, respuesta);
    }
}
