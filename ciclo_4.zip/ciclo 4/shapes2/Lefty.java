import java.util.ArrayList;

/**
 * Rueda lefty: si hay una rueda a su izquierda, al girar copia su estado
 * (queda mostrando el mismo simbolo). Si es la primera rueda gira normal.
 *
 * @author  (RodriguezH - SarmientoM)
 * @version (ciclo 4)
 */
public class Lefty extends Wheel
{
    public Lefty(ArrayList<String> colores, ArrayList<String> tipos) {
        super(colores, tipos);
    }

    /**
     * Gira copiando el simbolo visible de la rueda de la izquierda.
     * @param steps pasos (solo se usan si no hay rueda a la izquierda)
     * @param izquierda rueda de la izquierda (null si es la primera)
     */
    @Override
    public void spin(int steps, Wheel izquierda) {
        if (izquierda == null) {
            super.spin(steps, null);
        } else {
            avisarGiro();
            place(izquierda.getSymbol());
        }
    }

    @Override
    public String markColor() {
        return "blue";
    }
}
