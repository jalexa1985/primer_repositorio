import java.util.ArrayList;

/**
 * Rueda perezosa (tipo propuesto por nosotros): cuando le piden girar
 * solo gira la mitad de los pasos (redondeando hacia abajo).
 *
 * @author  (RodriguezH - SarmientoM)
 * @version (ciclo 4)
 */
public class Lazy extends Wheel
{
    public Lazy(ArrayList<String> colores, ArrayList<String> tipos) {
        super(colores, tipos);
    }

    @Override
    public void spin(int steps, Wheel izquierda) {
        super.spin(steps / 2, izquierda);
    }

    @Override
    public String markColor() {
        return "orange";
    }
}
