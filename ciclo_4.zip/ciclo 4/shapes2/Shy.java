/**
 * Simbolo timido: cada vez que queda seleccionado en la rueda
 * alterna entre visible e invisible.
 *
 * @author  (RodriguezH - SarmientoM)
 * @version (ciclo 4)
 */
public class Shy extends Symbol
{
    public Shy(String color) {
        super(color);
    }

    /**
     * Cada vez que el simbolo queda seleccionado cambia su visibilidad.
     */
    @Override
    public void selected() {
        visible = !visible;
    }

    @Override
    public String markColor() {
        return "black";
    }
}
