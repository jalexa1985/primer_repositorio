import java.util.ArrayList;

/**
 * Una rueda normal de la maquina. Tiene sus propios simbolos y muestra
 * el de su posicion actual. Los tipos de rueda (Lefty, Rebel, Lazy)
 * heredan de esta clase.
 *
 * @author  (RodriguezH - SarmientoM)
 * @version (ciclo 4)
 */
public class Wheel{

    private ArrayList<Symbol> symbols;
    private boolean isVisible;
    private int position;
    public boolean locked;

    private int x;              // posicion horizontal de la rueda en la maquina
    private Circle circulo;     // simbolo visible
    private int circuloX;       // posicion actual del circulo
    private int circuloY;
    private Triangle marcaSimbolo;   // marca del tipo de simbolo
    private int marcaSimboloX;
    private int marcaSimboloY;
    private Rectangle marcaRueda;    // marca del tipo de rueda
    private int marcaRuedaX;
    private int marcaRuedaY;

    /**
     * Crea una rueda con simbolos normales.
     * @param initialSymbols colores de los simbolos
     */
    public Wheel(ArrayList<String> initialSymbols) {
        this(initialSymbols, null);
    }

    /**
     * Crea una rueda con simbolos de los tipos dados.
     * @param colores colores de los simbolos
     * @param tipos tipo de cada simbolo (null = todos normales)
     */
    public Wheel(ArrayList<String> colores, ArrayList<String> tipos) {
        symbols = new ArrayList<Symbol>();
        for (int i = 0; i < colores.size(); i++) {
            String tipo = (tipos == null) ? "normal" : tipos.get(i);
            symbols.add(Symbol.create(tipo, colores.get(i)));
        }
        position = 0;
        locked = false;
        isVisible = false;
        circulo = new Circle(symbols.get(position).getColor());
        circulo.moveHorizontal(5);
        circulo.moveVertical(5);
        circuloX = 25;
        circuloY = 25;
        marcaSimbolo = new Triangle();
        marcaSimbolo.changeSize(14, 16);
        marcaSimboloX = 140;
        marcaSimboloY = 15;
        marcaRueda = new Rectangle();
        marcaRueda.changeSize(8, 70);
        marcaRuedaX = 10;
        marcaRuedaY = 10;
    }

    /**
     * Retorna el color del simbolo visible.
     */
    public String getSymbol(){
        return symbols.get(position).getColor();
    }

    /**
     * Retorna el simbolo visible.
     */
    public Symbol getVisibleSymbol() {
        return symbols.get(position);
    }

    public void addSymbol(int pos, String symbol){
        addSymbol(pos, "normal", symbol);
    }

    /**
     * Adiciona un simbolo del tipo dado en la posicion pos (desde 0).
     */
    public void addSymbol(int pos, String type, String color){
        symbols.add(pos, Symbol.create(type, color));
        dibujar();
    }

    public void delSymbol(String color){
        for (int i = 0; i < symbols.size(); i++) {
            if (symbols.get(i).getColor().equals(color)) {
                symbols.remove(i);
                break;
            }
        }
        if(position >= symbols.size()){
            position = 0;
        }
        dibujar();
    }

    /**
     * Gira la rueda el numero de pasos dado.
     */
    public void Spin(int steps){
        int n = symbols.size();
        position = ((position + steps) % n + n) % n;
        avisarGiro();
        symbols.get(position).selected();
        dibujar();
    }

    /**
     * Gira la rueda conociendo la rueda de su izquierda.
     * Una rueda normal no usa la rueda de la izquierda.
     * @param steps pasos a girar
     * @param izquierda rueda de la izquierda (null si es la primera)
     */
    public void spin(int steps, Wheel izquierda) {
        Spin(steps);
    }

    public void place(String color) {
        for(int i=0; i < symbols.size(); i++) {
            if(symbols.get(i).getColor().equals(color)){
                position = i;
                symbols.get(position).selected();
                dibujar();
                return;
            }
        }
    }

    public void lock() {
        locked = true;
    }

    public void unlock() {
        locked = false;
    }

    public boolean isLocked() {
        return locked;
    }

    /** Indica si la rueda se deja fijar. */
    public boolean canLock() {
        return true;
    }

    /** Indica si la rueda se deja intercambiar. */
    public boolean canSwap() {
        return true;
    }

    /** Indica si la rueda se deja eliminar. */
    public boolean canDelete() {
        return true;
    }

    /**
     * Color de la barra que identifica el tipo de rueda en pantalla.
     * @return null si la rueda no lleva marca (rueda normal)
     */
    public String markColor() {
        return null;
    }

    /**
     * Ubica la rueda en la posicion horizontal x de la maquina.
     */
    public void ubicar(int x) {
        this.x = x;
        dibujar();
    }

    public void makeVisible() {
        isVisible = true;
        dibujar();
    }

    public void makeInvisible() {
        borrar();
        isVisible = false;
    }

    /*
     * Avisa a todos los simbolos de la rueda que la rueda giro.
     */
    protected void avisarGiro() {
        for (Symbol s : symbols) {
            s.spun();
        }
    }

    /*
     * Borra las figuras de la rueda.
     */
    private void borrar() {
        circulo.makeInvisible();
        marcaSimbolo.makeInvisible();
        marcaRueda.makeInvisible();
    }

    /*
     * Dibuja el simbolo visible (con su tamano, centrado) y las marcas
     * del tipo de simbolo y del tipo de rueda.
     */
    private void dibujar() {
        borrar();
        if (!isVisible || symbols.isEmpty()) {
            return;
        }
        Symbol s = symbols.get(position);
        int margen = (Symbol.SIZE - s.getSize()) / 2;
        circulo.moveHorizontal(25 + x + margen - circuloX);
        circulo.moveVertical(25 + margen - circuloY);
        circuloX = 25 + x + margen;
        circuloY = 25 + margen;
        circulo.changeSize(s.getSize());
        circulo.changeColor(s.getColor());
        if (s.isVisible()) {
            circulo.makeVisible();
        }
        if (s.isVisible() && s.markColor() != null && s.getSize() >= 30) {
            marcaSimbolo.moveHorizontal(60 + x - marcaSimboloX);
            marcaSimbolo.moveVertical(circuloY + 3 - marcaSimboloY);
            marcaSimboloX = 60 + x;
            marcaSimboloY = circuloY + 3;
            marcaSimbolo.changeColor(s.markColor());
            marcaSimbolo.makeVisible();
        }
        if (markColor() != null) {
            marcaRueda.moveHorizontal(25 + x - marcaRuedaX);
            marcaRueda.moveVertical(101 - marcaRuedaY);
            marcaRuedaX = 25 + x;
            marcaRuedaY = 101;
            marcaRueda.changeColor(markColor());
            marcaRueda.makeVisible();
        }
    }
}
