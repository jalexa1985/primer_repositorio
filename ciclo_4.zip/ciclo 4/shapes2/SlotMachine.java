import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

public class SlotMachine {
    private ArrayList<Wheel> wheels;
    private ArrayList<String> symbols;
    private ArrayList<String> symbolTypes;
    private boolean isVisible;
    public Rectangle fondo1;
    public Rectangle fondo2;
    public int posicion;
    
    /** Colores que puede usar SlotMachine(n). */
    public static final String[] COLORES = {"red", "blue", "yellow", "green", "magenta",
        "black", "orange", "pink", "cyan", "gray", "purple", "brown", "lightGray", "darkGray"};
    
    public SlotMachine() {
        wheels = new ArrayList<Wheel>();
        symbols = new ArrayList<String>();
        symbolTypes = new ArrayList<String>();
        isVisible = false;
        posicion = 0;
        fondo1 = new Rectangle();
        fondo2 = new Rectangle();
        fondo2.changeSize(80, 80);
        fondo2.moveHorizontal(10);
        fondo2.moveVertical(10);
        fondo2.changeColor("white");
    }
    
    public SlotMachine(int n) {
        wheels = new ArrayList<Wheel>();
        symbols = new ArrayList<String>();
        symbolTypes = new ArrayList<String>();
        isVisible = false;
        posicion = 0;
        fondo1 = new Rectangle();
        fondo2 = new Rectangle();
        fondo2.changeSize(80, 80);
        fondo2.moveHorizontal(10);
        fondo2.moveVertical(10);
        fondo2.changeColor("white");
        for (int i = 0; i < n && i < COLORES.length; i++) {
            symbols.add(COLORES[i]);
            symbolTypes.add("normal");
        }
        for (int i = 0; i < symbols.size(); i++) {
            ArrayList<String> orden = new ArrayList<String>(symbols);
            Collections.shuffle(orden);
            Wheel rueda = new Wheel(orden);
            rueda.Spin((int) (Math.random() * orden.size()));
            wheels.add(rueda);
        }
        actualizar();
    }
    
    public void addWheel(int pos) {
        addWheel("normal", pos);
    }
    
    /**
     * Adiciona una rueda del tipo dado: "normal", "lefty", "rebel" o "lazy".
     * Si el tipo no existe no hace nada.
     */
    public void addWheel(String type, int pos) {
        if (pos < 1) {
            pos = 1;
        }
        if (pos > wheels.size() + 1) {
            pos = wheels.size() + 1;
        }
        Wheel rueda = crearRueda(type);
        if (rueda == null) {
            return;
        }
        wheels.add(pos - 1, rueda);
        actualizar();
    }
    
    public void delWheel(int pos) {
        if(pos > wheels.size() && pos < 0){
            System.out.println("Maximo posicion" + wheels.size() + "y minimo posicion 1");
        }else{
            if (!wheels.get(pos).canDelete()) {
                return;
            }
            Wheel rueda = wheels.remove(pos);
            rueda.makeInvisible();
        }
        actualizar();
    }
    
    public void swap(int wheel1, int wheel2) {
        Wheel auxiliar = wheels.get(wheel1 - 1);
        Wheel otra = wheels.get(wheel2 - 1);
        if (!auxiliar.canSwap() || !otra.canSwap()) {
            return;
        }
        wheels.set(wheel1 - 1, otra);
        wheels.set(wheel2 - 1, auxiliar);
        actualizar();
    }
    
    public void look(int wheel) {
        Wheel rueda = wheels.get(wheel-1);
        if (!rueda.canLock()) {
            return;
        }
        rueda.lock();
        wheels.set(wheel-1, rueda);
    }
    
    public void unlook(int wheel) {
        Wheel rueda = wheels.get(wheel-1);
        rueda.unlock();
        wheels.set(wheel-1, rueda);
    }
    
    public void addSymbol(int pos, String color) {
        addSymbol("normal", pos, color);
    }
    
    /**
     * Adiciona a todas las ruedas un simbolo del tipo dado:
     * "normal", "ephemeral" o "shy". Si el tipo no existe no hace nada.
     */
    public void addSymbol(String type, int pos, String color) {
        if (!Symbol.isType(type)) {
            return;
        }
        symbols.add(pos - 1, color);
        symbolTypes.add(pos - 1, type);
        for (Wheel w : wheels) {
            w.addSymbol(pos - 1, type, color);
        }
        actualizar();
    }

    public void delSymbol(String symbol) {
        int i = symbols.indexOf(symbol);
        if (i < 0) {
            return;
        }
        symbols.remove(i);
        symbolTypes.remove(i);
        for (Wheel w : wheels) {
            w.delSymbol(symbol);
        }
        actualizar();
    }

    public void placeSymbol(int wheel, String symbol) {
        Wheel rueda = this.wheels.get(wheel-1);
        rueda.place(symbol);
        wheels.set(wheel-1, rueda);
        actualizar();
    }

    public void spin(int wheel) {
        if(wheels.get(wheel-1).isLocked() == true) {
            return;
        }
        Wheel rueda = wheels.get(wheel-1);
        rueda.spin((int) (Math.random() * symbols.size()) + 1, izquierdaDe(wheel - 1));
        actualizar();
    }

    public void spin() {
        for(int i = 0; i < wheels.size();i++)
            if(wheels.get(i).isLocked() == true) {
                return;
            } else {
                Wheel rueda = wheels.get(i);
                rueda.spin((int) (Math.random() * symbols.size()) + 1, izquierdaDe(i));
            }
        actualizar();
    }
    
    public void spin(int wheel, int steps) {
        if(wheels.get(wheel-1).isLocked() == true) {
            return;
        }
        Wheel rueda = wheels.get(wheel-1);
        rueda.spin(steps, izquierdaDe(wheel - 1));
        actualizar();
    }
    
    public void spin(String[] setSymbols) {
        for (int i = 0; i < setSymbols.length; i++) {
            wheels.get(i).place(setSymbols[i]);
        }
        actualizar();
    }

    public String[] symbols() {
        String[] currentSymbols= new String[symbols.size()];
        for(int i = 0; i <  symbols.size();i++){
            currentSymbols[i] = symbols.get(i);
        }
        return currentSymbols;
    }

    public int distinctSymbols() {
        ArrayList<String> currentSymbols = new ArrayList<String>();
        String[] actualSymbols = configuration();
        for(int i = 0; i < actualSymbols.length; i++){
            currentSymbols.add(actualSymbols[i]);
        } 
        for (int i = 0; i < currentSymbols.size(); i++) {
            for (int j = i + 1; j < currentSymbols.size(); j++) {
                if (currentSymbols.get(i).equals(currentSymbols.get(j))) {
                    currentSymbols.remove(j);
                    j--;
                }
            }
        }
        return currentSymbols.size();
    }

    public String[] configuration() {
        String[] config = new String[wheels.size()];
        for (int i = 0; i < config.length; i++) {
            config[i] = wheels.get(i).getSymbol();
        }
        return config;
    }

    public boolean isJackpot() {
        if(distinctSymbols() == 1){
            return true;
        } else {
            return false;
        }
    }

    public void makeVisible() {
        fondo1.makeVisible();
        fondo2.makeVisible();
        for(Wheel w: wheels){
            w.makeVisible();
        }
        isVisible = true;
    }

    public void makeInvisible() {
        fondo1.makeInvisible();
        fondo2.makeInvisible();
        for(Wheel w: wheels){
            w.makeInvisible();
        }
        isVisible = false;
    }

    public void exit() {
    }

    public boolean ok() {
        return false;
    }
    
    public void actualizar() {
        int n = Math.max(wheels.size(), 1);
        int anchoFondo1 = n * 100;
        fondo1.changeSize(100, anchoFondo1);
        fondo2.changeSize(80, anchoFondo1 - 20);
        for (int i = 0; i < wheels.size(); i++) {
            posicion = i * 100;
            wheels.get(i).ubicar(posicion);
        }
        if (isJackpot() == true || distinctSymbols() == 1) {
            fondo1.changeColor("green");
        } else {
            fondo1.changeColor("black");
        }
        if (isVisible) {
            makeVisible();
        }
        }
    
    /*
     * Crea una rueda del tipo dado con los simbolos actuales de la maquina.
     * Retorna null si el tipo no existe.
     */
    private Wheel crearRueda(String type) {
        if (type == null) {
            return null;
        }
        if (type.equals("normal")) {
            return new Wheel(symbols, symbolTypes);
        }
        if (type.equals("lefty")) {
            return new Lefty(symbols, symbolTypes);
        }
        if (type.equals("rebel")) {
            return new Rebel(symbols, symbolTypes);
        }
        if (type.equals("lazy")) {
            return new Lazy(symbols, symbolTypes);
        }
        return null;
    }
    
    /*
     * Retorna la rueda a la izquierda de la rueda en el indice dado (desde 0),
     * o null si es la primera.
     */
    private Wheel izquierdaDe(int indice) {
        return (indice > 0) ? wheels.get(indice - 1) : null;
    }
}
