/**
 * Un simbolo normal de una rueda: tiene un color, un tamano y puede verse o no.
 * Los tipos de simbolo (Ephemeral, Shy) heredan de esta clase y cambian
 * lo que pasa cuando la rueda gira o cuando el simbolo queda seleccionado.
 *
 * @author  (RodriguezH - SarmientoM)
 * @version (ciclo 4)
 */
public class Symbol
{
    /** Tamano inicial (diametro) de un simbolo. */
    public static final int SIZE = 70;

    protected String color;
    protected int size;
    protected boolean visible;

    /**
     * Crea un simbolo normal.
     * @param color color del simbolo
     */
    public Symbol(String color) {
        this.color = color;
        size = SIZE;
        visible = true;
    }

    /**
     * Crea un simbolo del tipo dado.
     * @param type "normal", "ephemeral" o "shy"
     * @param color color del simbolo
     * @return el simbolo creado
     */
    public static Symbol create(String type, String color) {
        if (type.equals("ephemeral")) {
            return new Ephemeral(color);
        }
        if (type.equals("shy")) {
            return new Shy(color);
        }
        return new Symbol(color);
    }

    /**
     * Indica si un tipo de simbolo existe.
     * @param type tipo a revisar
     * @return true si es "normal", "ephemeral" o "shy"
     */
    public static boolean isType(String type) {
        return type != null && (type.equals("normal") || type.equals("ephemeral") || type.equals("shy"));
    }

    public String getColor() {
        return color;
    }

    public int getSize() {
        return size;
    }

    public boolean isVisible() {
        return visible;
    }

    /**
     * Avisa que la rueda donde esta el simbolo giro.
     * Un simbolo normal no cambia.
     */
    public void spun() {
    }

    /**
     * Avisa que el simbolo quedo como el visible de la rueda.
     * Un simbolo normal no cambia.
     */
    public void selected() {
    }

    /**
     * Color de la marca que identifica el tipo de simbolo en pantalla.
     * @return null si el simbolo no lleva marca
     */
    public String markColor() {
        return null;
    }
}
