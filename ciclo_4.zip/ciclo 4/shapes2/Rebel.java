import java.util.ArrayList;

/**
 * Rueda rebelde: no se deja fijar, ni intercambiar, ni eliminar.
 *
 * @author  (RodriguezH - SarmientoM)
 * @version (ciclo 4)
 */
public class Rebel extends Wheel
{
    public Rebel(ArrayList<String> colores, ArrayList<String> tipos) {
        super(colores, tipos);
    }

    @Override
    public boolean canLock() {
        return false;
    }

    @Override
    public boolean canSwap() {
        return false;
    }

    @Override
    public boolean canDelete() {
        return false;
    }

    @Override
    public String markColor() {
        return "red";
    }
}
