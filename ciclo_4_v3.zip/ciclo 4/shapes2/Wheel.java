import java.util.ArrayList;
import java.util.Random;

/**
 * Rueda normal de la maquina. Tiene sus propios simbolos y muestra el de su
 * posicion actual. Los tipos de rueda (Lefty, Rebel, Lazy) heredan de esta
 * clase y sobrescriben lo que necesitan.
 *
 * @author (RodriguezH - SarmientoM)
 * @version (ciclo 4)
 */
public class Wheel{
    protected ArrayList<Wheel> wheels;
    private ArrayList<Symbol> symbols;
    private Random random;
    private boolean isVisible;
    private int position;
    private String type;
    private boolean locked;
    private Circle shape;

    private int x;                   // posicion horizontal de la rueda en la maquina
    private int shapeY;              // posicion vertical actual del circulo
    private Triangle marcaSimbolo;   // marca del tipo de simbolo
    private int marcaSimboloX;
    private int marcaSimboloY;
    private Rectangle marcaRueda;    // barra del tipo de rueda
    private int marcaRuedaX;
    private int marcaRuedaY;

    public Wheel(ArrayList<Symbol> initialSymbols, String newType){
        this(initialSymbols);
        type = newType;
    }

    public Wheel(ArrayList<Symbol> initialSymbols) {
        symbols = new ArrayList<Symbol>();
        for (Symbol s : initialSymbols) {
            symbols.add(s.copy());          // cada rueda con sus propios simbolos
        }
        position = 0;
        locked = false;
        isVisible = false;
        shape = new Circle(symbols.get(position).getColor());
        shape.moveHorizontal(5);
        shape.moveVertical(5);
        shapeY = 25;
        type = "normal";
        marcaSimbolo = new Triangle();      // nace en (140, 15)
        marcaSimbolo.changeSize(14, 16);
        marcaSimboloX = 140;
        marcaSimboloY = 15;
        marcaRueda = new Rectangle();       // nace en (10, 10)
        marcaRueda.changeSize(8, 70);
        marcaRuedaX = 10;
        marcaRuedaY = 10;
    }

    public int getPos(){
        return position;
    }

    public ArrayList<Symbol> getSymbols(){
        return symbols;
    }

    public String getSymbol(){
        return symbols.get(position).getColor();
    }

    public void addSymbol(int pos, String symbol){
        symbols.add(pos, new Symbol(symbol));
    }

    public void delSymbol(String color){
        if(position == symbols.size() - 1 && symbols.size() > 1){
            position -= 1;
        }
        for(int i = 0; i < symbols.size(); i++){
            if(symbols.get(i).getColor().equals(color)){
                symbols.remove(i);
            }
        }
        dibujar();
    }

    /**
     * Gira la rueda: avisa a sus simbolos que giro y al nuevo visible
     * que quedo seleccionado.
     */
    public void Spin(int steps){
        int n = symbols.size();
        position = ((position + steps) % n + n) % n;
        avisarGiro();
        symbols.get(position).selected();
        dibujar();
    }

    public void place(String color) {
        for(int i = 0; i < symbols.size(); i++) {
            if(symbols.get(i).getColor().equals(color)){
                position = i;
                symbols.get(position).selected();
                dibujar();
                return;
            }
        }
    }

    public String getType(){
        return type;
    }

    public void lock() {
        locked = true;
    }

    public void unlock() {
        locked = false;
    }

    public boolean isLocked() {
        return locked;
    }

    /** Indica si la rueda se deja fijar. */
    public boolean canLock() {
        return true;
    }

    /** Indica si la rueda se deja intercambiar. */
    public boolean canSwap() {
        return true;
    }

    /** Indica si la rueda se deja eliminar. */
    public boolean canDelete() {
        return true;
    }

    /**
     * Color de la barra que identifica el tipo de rueda en pantalla.
     * @return null si no lleva barra (rueda normal)
     */
    public String markColor() {
        return null;
    }

    /**
     * Ubica la rueda en la posicion horizontal x de la maquina.
     */
    public void ubicar(int x) {
        this.x = x;
        dibujar();
    }

    public void makeVisible() {
        isVisible = true;
        dibujar();
    }

    public void makeInvisible() {
        borrar();
        isVisible = false;
    }

    public Circle getShape() {
        return shape;
    }

    /*
     * Avisa a todos los simbolos de la rueda que la rueda giro.
     */
    protected void avisarGiro() {
        for (Symbol s : symbols) {
            s.spun();
        }
    }

    /*
     * Borra el circulo y las marcas.
     */
    private void borrar() {
        shape.makeInvisible();
        marcaSimbolo.makeInvisible();
        marcaRueda.makeInvisible();
    }

    /*
     * Dibuja el simbolo visible centrado y con su tamano, la marca del tipo
     * de simbolo y la barra del tipo de rueda.
     */
    private void dibujar() {
        borrar();
        if (!isVisible || symbols.isEmpty()) {
            return;
        }
        Symbol s = symbols.get(position);
        int margen = (70 - s.getSize()) / 2;
        shape.moveHorizontalTo(x + margen);
        shape.moveVertical(25 + margen - shapeY);
        shapeY = 25 + margen;
        shape.changeSize(s.getSize());
        shape.changeColor(s.getColor());
        if (s.isVisible()) {
            shape.makeVisible();
        }
        if (s.isVisible() && s.markColor() != null && s.getSize() >= 30) {
            marcaSimbolo.moveHorizontal(60 + x - marcaSimboloX);
            marcaSimbolo.moveVertical(shapeY + 3 - marcaSimboloY);
            marcaSimboloX = 60 + x;
            marcaSimboloY = shapeY + 3;
            marcaSimbolo.changeColor(s.markColor());
            marcaSimbolo.makeVisible();
        }
        if (markColor() != null) {
            marcaRueda.moveHorizontal(25 + x - marcaRuedaX);
            marcaRueda.moveVertical(101 - marcaRuedaY);
            marcaRuedaX = 25 + x;
            marcaRuedaY = 101;
            marcaRueda.changeColor(markColor());
            marcaRueda.makeVisible();
        }
    }
}
