
/**
 * Simbolo normal de una rueda: tiene un color, un tamano y puede verse o no.
 * Los tipos de simbolo (Ephemeral, Shy) heredan de esta clase y sobrescriben
 * lo que pasa cuando la rueda gira o cuando el simbolo queda seleccionado.
 * 
 * @author (RodriguezH - SarmientoM)
 * @version (ciclo 4)
 */
public class Symbol {
    protected String color;
    protected int size;
    protected boolean visible;
    protected String type;

    public Symbol(String color, String newType) {
        this(color);
        type = newType;
    }
    
    public Symbol(String color) {
        this.color = color;
        size = 70;
        visible = true;
        type = "normal";
    }

    /**
     * Crea un simbolo del tipo dado.
     * @param type "normal", "ephemeral" o "shy"
     * @param color color del simbolo
     * @return el simbolo, o null si el tipo no existe
     */
    public static Symbol create(String type, String color) {
        if (type.equals("ephemeral")){
            return new Ephemeral(color, type);
        }
        if (type.equals("shy")){
            return new Shy(color, type);
        }
        if (type.equals("normal")){
            return new Symbol(color, type);
        }
        return null;
    }

    public String getColor()   {
        return color;
    }
    
    public int getSize()       {
        return size;
    }
    
    public boolean isVisible() {
        return visible;
    }
    
    public String getType() {
        return type;
    }
    
    /**
     * Crea un simbolo nuevo del mismo tipo y color (cada rueda tiene sus propios simbolos).
     */
    public Symbol copy() {
        return new Symbol(color, type);
    }
    
    /**
     * Avisa que la rueda donde esta el simbolo giro. Un simbolo normal no cambia.
     */
    public void spun() {
    }
    
    /**
     * Avisa que el simbolo quedo como el visible de la rueda. Un simbolo normal no cambia.
     */
    public void selected() {
    }
    
    /**
     * Color de la marca que identifica el tipo de simbolo en pantalla.
     * @return null si no lleva marca (simbolo normal)
     */
    public String markColor() {
        return null;
    }
}
