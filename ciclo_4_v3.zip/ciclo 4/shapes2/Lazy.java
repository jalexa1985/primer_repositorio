import java.util.ArrayList;


/**
 * Rueda perezosa (tipo propuesto por nosotros): solo avanza la mitad de los
 * pasos que le piden. Los pasos que sobran se acumulan, asi que dos giros de
 * un paso hacen que avance una posicion.
 * 
 * @author (RodriguezH - SarmientoM)
 * @version (ciclo 4)
 */
public class Lazy extends Wheel
{
    private int pendientes;
    
    public Lazy(ArrayList<Symbol> initialSymbols, String type){
        super(initialSymbols, type);
        pendientes = 0;
    }
    
    @Override
    public void Spin(int steps){
        pendientes += steps;
        int avanza = pendientes / 2;
        pendientes = pendientes % 2;
        if (avanza > 0) {
            super.Spin(avanza);
        }
    }
    
    @Override
    public String markColor() {
        return "magenta";
    }
}
