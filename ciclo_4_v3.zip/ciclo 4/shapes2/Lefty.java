import java.util.ArrayList;


/**
 * Rueda lefty: si hay una rueda a su izquierda, al girar copia su estado
 * (queda mostrando el mismo simbolo). Si es la primera, gira normal.
 * 
 * @author (RodriguezH - SarmientoM)
 * @version (ciclo 4)
 */
public class Lefty extends Wheel
{
    public Lefty (ArrayList<Symbol> initialSymbols, String type, ArrayList<Wheel> ruedas){
        super(initialSymbols, type);
        wheels = ruedas;                    // la misma lista de la maquina
    }
    
    @Override
    public void Spin(int steps){
        int i = wheels.indexOf(this);
        if (i > 0) {
            Wheel ruedaIzquierda = wheels.get(i-1);
            String color = ruedaIzquierda.getSymbol();
            avisarGiro();                   // tambien es un giro: los efimeros se encogen
            place(color);
        } else {
            super.Spin(steps);
        }
    }
    
    @Override
    public String markColor() {
        return "blue";
    }
}
