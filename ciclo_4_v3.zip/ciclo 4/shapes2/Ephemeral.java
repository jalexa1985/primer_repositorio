
/**
 * Simbolo efimero: en cada giro de su rueda se hace mas pequeno
 * hasta quedar como un punto.
 * 
 * @author (RodriguezH - SarmientoM)
 * @version (ciclo 4)
 */
public class Ephemeral extends Symbol
{
    /** Tamano minimo: el simbolo queda como un punto. */
    public static final int MIN_SIZE = 5;
    /** Lo que se reduce el tamano en cada giro. */
    public static final int STEP = 10;
    
    public Ephemeral (String color, String type){
        super(color, type);
    }
    
    @Override
    public Symbol copy() {
        return new Ephemeral(color, type);
    }
    
    /**
     * En cada giro se reduce, sin bajar de MIN_SIZE.
     */
    @Override
    public void spun() {
        size = Math.max(MIN_SIZE, size - STEP);
    }
    
    @Override
    public String markColor() {
        return "white";
    }
}
