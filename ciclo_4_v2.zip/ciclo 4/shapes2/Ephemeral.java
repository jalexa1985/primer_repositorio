
/**
 * Write a description of class Ephemeral here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Ephemeral extends Symbol
{
    public Ephemeral (String color, String type){
        super(color, type);
    }
}