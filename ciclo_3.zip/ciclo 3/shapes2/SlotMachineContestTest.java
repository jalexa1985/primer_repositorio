import static org.junit.Assert.*;
import org.junit.Test;

/**
 * Pruebas de unidad del ciclo 3 (modo invisible).
 *
 * @author  (RodriguezH - SarmientoM)
 * @version (ciclo 3)
 */
public class SlotMachineContestTest
{
    @Test
    public void shouldCreateMachineWithNWheelsAndNSymbols() {
        SlotMachine m = new SlotMachine(6);
        assertEquals(6, m.configuration().length);
        assertEquals(6, m.symbols().length);
    }

    @Test
    public void shouldNotCreateMachineWithRepeatedSymbols() {
        SlotMachine m = new SlotMachine(SlotMachine.COLORES.length);
        String[] s = m.symbols();
        for (int i = 0; i < s.length; i++) {
            for (int j = i + 1; j < s.length; j++) {
                assertFalse(s[i].equals(s[j]));
            }
        }
    }

    @Test
    public void shouldReturnValidActions() {
        int n = 6;
        int[][] acciones = SlotMachineContest.solve(n);
        assertTrue(acciones.length <= 2 * n * n + n + 1);
        for (int[] a : acciones) {
            assertTrue(a[0] >= 1 && a[0] <= n);
            assertTrue(a[1] >= 1 && a[1] < n);
        }
    }

    @Test
    public void shouldNotNeedActionsWithOneWheel() {
        assertEquals(0, SlotMachineContest.solve(1).length);
    }

    @Test
    public void shouldNotSolveInvalidSizes() {
        assertEquals(0, SlotMachineContest.solve(0).length);
        assertEquals(0, SlotMachineContest.solve(SlotMachine.COLORES.length + 1).length);
    }
}
