import java.util.ArrayList;

/**
 * Solucion del Problem I (Slot Machine) de la maraton internacional 2025.
 * SlotMachine se usa solo como testing tool: SlotMachine(n), spin(wheel,steps)
 * y distinctSymbols(); y como simulador: makeVisible() y makeInvisible().
 *
 * @author  (RodriguezH - SarmientoM)
 * @version (ciclo 3)
 */
public class SlotMachineContest
{
    private static boolean simular = false;

    /**
     * Resuelve el problema para una maquina de n ruedas y n simbolos
     * inicializada aleatoriamente. La maquina permanece invisible
     * (visible solo cuando lo llama simulate).
     *
     * 1. Deja todas las ruedas con simbolos distintos: cada rueda prueba sus
     *    n posiciones y se queda donde hay mas simbolos distintos.
     * 2. Gira la rueda 1 un paso para que su simbolo T deje de verse. Cada otra
     *    rueda prueba sus n posiciones: donde hay mas simbolos distintos
     *    (sin contar la posicion actual) esta T. La rueda vuelve a su lugar.
     * 3. Devuelve la rueda 1 a T y gira cada rueda hasta T.
     *
     * @param n numero de ruedas y simbolos (1 a SlotMachine.COLORES.length)
     * @return acciones {rueda, pasos} necesarias para ganar
     */
    public static int[][] solve(int n) {
        ArrayList<int[]> acciones = new ArrayList<int[]>();
        if (n < 1 || n > SlotMachine.COLORES.length) {
            return new int[0][];
        }
        SlotMachine machine = new SlotMachine(n);
        if (simular) {
            machine.makeVisible();
        } else {
            machine.makeInvisible();
        }
        if (n > 1 && machine.distinctSymbols() > 1) {
            // 1. todas las ruedas con simbolos distintos
            for (int rueda = 1; rueda <= n && machine.distinctSymbols() < n; rueda++) {
                int mejor = 0;
                int maximo = machine.distinctSymbols();
                for (int p = 1; p < n; p++) {
                    machine.spin(rueda, 1);
                    acciones.add(new int[]{rueda, 1});
                    if (machine.distinctSymbols() > maximo) {
                        maximo = machine.distinctSymbols();
                        mejor = p;
                    }
                }
                int pasos = (mejor + 1) % n;
                if (pasos > 0) {
                    machine.spin(rueda, pasos);
                    acciones.add(new int[]{rueda, pasos});
                }
            }
            // 2. buscar en cada rueda el simbolo T de la rueda 1
            machine.spin(1, 1);
            acciones.add(new int[]{1, 1});
            int[] objetivo = new int[n + 1];
            for (int rueda = 2; rueda <= n; rueda++) {
                int maximo = -1;
                for (int p = 1; p <= n; p++) {
                    machine.spin(rueda, 1);
                    acciones.add(new int[]{rueda, 1});
                    if (p < n && machine.distinctSymbols() > maximo) {
                        maximo = machine.distinctSymbols();
                        objetivo[rueda] = p;
                    }
                }
            }
            // 3. todas las ruedas a T
            machine.spin(1, n - 1);
            acciones.add(new int[]{1, n - 1});
            for (int rueda = 2; rueda <= n; rueda++) {
                machine.spin(rueda, objetivo[rueda]);
                acciones.add(new int[]{rueda, objetivo[rueda]});
            }
        }
        return acciones.toArray(new int[0][]);
    }

    /**
     * Simula, en una maquina visible, las acciones necesarias para ganar.
     * Solo es posible si 1 <= n <= 10 (lo que cabe en el canvas).
     * @param n numero de ruedas y simbolos
     */
    public static void simulate(int n) {
        if (n < 1 || n > 10) {
            return;
        }
        simular = true;
        solve(n);
        simular = false;
    }
}
