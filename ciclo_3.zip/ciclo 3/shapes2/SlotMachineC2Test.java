import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;
import org.junit.After;


/**
 * The test class SlotMachineC2Test.
 * Cada metodo de SlotMachine tiene dos pruebas:
 * should... (lo que deberia hacer) y shouldNot... (lo que no deberia hacer).
 *
 * @author  (RodriguezH - SarmientoM)
 * @version (6/09/2026)
 */
public class SlotMachineC2Test
{
    private SlotMachine machine;

    /**
     * Maquina con los simbolos red, blue, yellow (en ese orden) y 3 ruedas.
     * Todas las ruedas empiezan mostrando "red".
     */
    @Before
    public void setUp() {
        machine = new SlotMachine();
        machine.addSymbol(1, "red");
        machine.addSymbol(2, "blue");
        machine.addSymbol(3, "yellow");
        machine.addWheel(1);
        machine.addWheel(2);
        machine.addWheel(3);
    }

    // ---------------- SlotMachine() ----------------

    @Test
    public void shouldCreateEmptyMachine() {
        SlotMachine empty = new SlotMachine();
        assertEquals(0, empty.symbols().length);
        assertEquals(0, empty.configuration().length);
    }

    @Test
    public void shouldNotCreateMachineWithJackpot() {
        SlotMachine empty = new SlotMachine();
        assertFalse(empty.isJackpot());
    }

    // ---------------- SlotMachine(n) ----------------

    @Test
    public void shouldCreateMachineWithNWheels() {
        SlotMachine m = new SlotMachine(4);
        assertEquals(4, m.configuration().length);
        assertEquals(5, m.symbols().length);
    }

    @Test
    public void shouldNotCreateWheelsWhenNIsZero() {
        SlotMachine m = new SlotMachine(0);
        assertEquals(0, m.configuration().length);
    }

    // ---------------- addWheel ----------------

    @Test
    public void shouldAddWheel() {
        machine.addWheel(4);
        assertEquals(4, machine.configuration().length);
        assertEquals("red", machine.configuration()[3]);
    }

    @Test(expected = IndexOutOfBoundsException.class)
    public void shouldNotAddWheelWithoutSymbols() {
        SlotMachine empty = new SlotMachine();
        empty.addWheel(1);
    }

    // ---------------- delWheel ----------------

    @Test
    public void shouldDeleteWheel() {
        machine.delWheel(1);
        assertEquals(2, machine.configuration().length);
    }

    @Test(expected = IndexOutOfBoundsException.class)
    public void shouldNotDeleteWheelThatDoesNotExist() {
        SlotMachine empty = new SlotMachine();
        empty.delWheel(1);
    }

    // ---------------- swap ----------------

    @Test
    public void shouldSwapWheels() {
        machine.spin(1, 1);                       // rueda 1: blue
        machine.swap(1, 3);
        assertArrayEquals(new String[]{"red", "red", "blue"}, machine.configuration());
    }

    @Test(expected = IndexOutOfBoundsException.class)
    public void shouldNotSwapWheelThatDoesNotExist() {
        machine.swap(1, 5);
    }

    // ---------------- look ----------------

    @Test
    public void shouldLockWheel() {
        machine.look(1);
        machine.spin(1, 1);
        assertEquals("red", machine.configuration()[0]);
    }

    @Test
    public void shouldNotLockOtherWheels() {
        machine.look(1);
        machine.spin(2, 1);
        assertEquals("blue", machine.configuration()[1]);
    }

    // ---------------- unlook ----------------

    @Test
    public void shouldUnlockWheel() {
        machine.look(1);
        machine.unlook(1);
        machine.spin(1, 1);
        assertEquals("blue", machine.configuration()[0]);
    }

    @Test
    public void shouldNotUnlockOtherWheels() {
        machine.look(1);
        machine.look(2);
        machine.unlook(1);
        machine.spin(2, 1);
        assertEquals("red", machine.configuration()[1]);
    }

    // ---------------- addSymbol ----------------

    @Test
    public void shouldAddSymbolInPosition() {
        machine.addSymbol(2, "green");
        assertArrayEquals(new String[]{"red", "green", "blue", "yellow"}, machine.symbols());
    }

    @Test(expected = IndexOutOfBoundsException.class)
    public void shouldNotAddSymbolInPositionZero() {
        machine.addSymbol(0, "green");
    }

    // ---------------- delSymbol ----------------

    @Test
    public void shouldDeleteSymbol() {
        machine.delSymbol("yellow");
        assertArrayEquals(new String[]{"red", "blue"}, machine.symbols());
    }

    @Test
    public void shouldNotDeleteSymbolThatDoesNotExist() {
        machine.delSymbol("green");
        assertEquals(3, machine.symbols().length);
    }

    // ---------------- placeSymbol ----------------

    @Test
    public void shouldPlaceSymbol() {
        machine.placeSymbol(2, "yellow");
        assertEquals("yellow", machine.configuration()[1]);
    }

    @Test
    public void shouldNotPlaceSymbolThatDoesNotExist() {
        machine.placeSymbol(2, "green");
        assertEquals("red", machine.configuration()[1]);
    }

    // ---------------- spin(wheel) ----------------

    @Test
    public void shouldSpinWheelToAValidSymbol() {
        machine.spin(1);
        String s = machine.configuration()[0];
        assertTrue(s.equals("red") || s.equals("blue") || s.equals("yellow"));
    }

    @Test
    public void shouldNotSpinLockedWheel() {
        machine.look(1);
        machine.spin(1);
        assertEquals("red", machine.configuration()[0]);
    }

    // ---------------- spin() ----------------

    @Test
    public void shouldSpinAllWheelsToValidSymbols() {
        machine.spin();
        for (String s : machine.configuration()) {
            assertTrue(s.equals("red") || s.equals("blue") || s.equals("yellow"));
        }
    }

    @Test
    public void shouldNotSpinWhenFirstWheelIsLocked() {
        machine.look(1);
        machine.spin();
        assertArrayEquals(new String[]{"red", "red", "red"}, machine.configuration());
    }

    // ---------------- spin(wheel, steps) ----------------

    @Test
    public void shouldSpinWheelSteps() {
        machine.spin(1, 2);
        assertEquals("yellow", machine.configuration()[0]);
        machine.spin(1, 1);                       // da la vuelta completa
        assertEquals("red", machine.configuration()[0]);
    }

    @Test
    public void shouldNotSpinLockedWheelSteps() {
        machine.look(3);
        machine.spin(3, 2);
        assertEquals("red", machine.configuration()[2]);
    }

    // ---------------- spin(String[]) ----------------

    @Test
    public void shouldSetConfiguration() {
        machine.spin(new String[]{"yellow", "blue", "red"});
        assertArrayEquals(new String[]{"yellow", "blue", "red"}, machine.configuration());
    }

    @Test
    public void shouldNotSetSymbolThatDoesNotExist() {
        machine.spin(new String[]{"blue", "green", "blue"});
        assertArrayEquals(new String[]{"blue", "red", "blue"}, machine.configuration());
    }

    // ---------------- symbols ----------------

    @Test
    public void shouldReturnSymbolsInOrder() {
        assertArrayEquals(new String[]{"red", "blue", "yellow"}, machine.symbols());
    }

    @Test
    public void shouldNotChangeMachineWhenChangingReturnedSymbols() {
        String[] s = machine.symbols();
        s[0] = "green";
        assertEquals("red", machine.symbols()[0]);
    }

    // ---------------- distinctSymbols ----------------

    @Test
    public void shouldHaveDiferentSymbols() {
        machine.spin(2, 1);
        machine.spin(3, 2);
        assertEquals(3, machine.distinctSymbols());
    }

    @Test
    public void shouldNotHaveDiferentSymbols() {
        machine.spin(2, 1);
        machine.spin(3, 1);
        assertEquals(2, machine.distinctSymbols());
    }

    // ---------------- configuration ----------------

    @Test
    public void shouldReturnVisibleSymbols() {
        machine.spin(2, 1);
        assertArrayEquals(new String[]{"red", "blue", "red"}, machine.configuration());
    }

    @Test
    public void shouldNotReturnSymbolsWithoutWheels() {
        SlotMachine empty = new SlotMachine();
        empty.addSymbol(1, "red");
        assertEquals(0, empty.configuration().length);
    }

    // ---------------- isJackpot ----------------

    @Test
    public void shouldBeJackpot() {
        machine.spin(new String[]{"blue", "blue", "blue"});
        assertTrue(machine.isJackpot());
    }

    @Test
    public void shouldNotBeJackpot() {
        machine.spin(2, 1);
        assertFalse(machine.isJackpot());
    }

    // ---------------- makeVisible ----------------

    @Test
    public void shouldMakeVisibleKeepingConfiguration() {
        machine.makeVisible();
        assertArrayEquals(new String[]{"red", "red", "red"}, machine.configuration());
    }

    @Test
    public void shouldNotChangeSymbolsWhenMakingVisible() {
        machine.makeVisible();
        assertEquals(3, machine.symbols().length);
    }

    // ---------------- makeInvisible ----------------

    @Test
    public void shouldMakeInvisibleKeepingConfiguration() {
        machine.makeInvisible();
        assertArrayEquals(new String[]{"red", "red", "red"}, machine.configuration());
    }

    @Test
    public void shouldNotDeleteWheelsWhenMakingInvisible() {
        machine.makeInvisible();
        assertEquals(3, machine.configuration().length);
    }

    // ---------------- exit ----------------

    @Test
    public void shouldExitKeepingSymbols() {
        machine.exit();
        assertEquals(3, machine.symbols().length);
    }

    @Test
    public void shouldNotChangeConfigurationWhenExiting() {
        machine.exit();
        assertArrayEquals(new String[]{"red", "red", "red"}, machine.configuration());
    }

    // ---------------- ok ----------------

    @Test
    public void shouldBeOkAfterValidOperation() {
        machine.addWheel(4);
        assertTrue(machine.ok());       // FALLA: ok() siempre retorna false
    }

    @Test
    public void shouldNotBeOkAfterInvalidOperation() {
        machine.placeSymbol(1, "green");
        assertFalse(machine.ok());
    }

    // ---------------- actualizar ----------------

    @Test
    public void shouldUpdateKeepingConfiguration() {
        machine.spin(2, 1);
        machine.actualizar();
        assertArrayEquals(new String[]{"red", "blue", "red"}, machine.configuration());
    }

    @Test
    public void shouldNotChangeNumberOfWheelsWhenUpdating() {
        machine.actualizar();
        assertEquals(3, machine.configuration().length);
    }

    @After
    public void erase(){
    }
}
