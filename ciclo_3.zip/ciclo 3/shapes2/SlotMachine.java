import java.util.ArrayList;
import java.util.Random;

public class SlotMachine {
    private ArrayList<Wheel> wheels;
    private ArrayList<String> symbols;
    private boolean isVisible;
    public Rectangle fondo1;
    public Rectangle fondo2;
    
    private static final int SEPARACION = 10;
    
    public SlotMachine() {
        wheels = new ArrayList<Wheel>();
        symbols = new ArrayList<String>();
        isVisible = false;
        fondo1 = new Rectangle();
        fondo1.changeColor("black");
        fondo2 = new Rectangle();
        fondo2.moveHorizontal(SEPARACION);
        fondo2.moveVertical(SEPARACION);
        fondo2.changeColor("white");
        redraw();
    }

    public void addWheel(int pos) {
        if (pos < 1) {
            pos = 1;
        }
        if (pos > wheels.size() + 1) {
            pos = wheels.size() + 1;
        }
        wheels.add(pos - 1, new Wheel(symbols));
        redraw();
    }
    
    public void delWheel(int pos) {
        if (wheels.isEmpty()) {
            return;
        }
        if (pos < 1) {
            pos = 1;
        }
        if (pos > wheels.size()) {
            pos = wheels.size();
        }
        Wheel rueda = wheels.remove(pos - 1);
        rueda.makeInvisible();
        redraw();
    }
    
    public void swap(int wheel1, int wheel2) {
        Wheel auxiliar = wheels.get(wheel1 - 1);
        wheels.set(wheel1 - 1, wheels.get(wheel2 - 1));
        wheels.set(wheel2 - 1, auxiliar);
        redraw();
    }
    
    public void look(int wheel) {
        Wheel rueda = wheels.get(wheel-1);
        rueda.lock();
        wheels.set(wheel-1, rueda);
    }
    
    public void unlook(int wheel) {
        Wheel rueda = wheels.get(wheel-1);
        rueda.unlock();
        wheels.set(wheel-1, rueda);
    }
    
    public void addSymbol(int pos, String color) {
        symbols.add(pos, color);
        for (Wheel w : wheels) {
            w.addSymbol(pos, color);
        }
    }

    public void delSymbol(String symbol) {
        symbols.remove(symbol);
        for (Wheel w : wheels) {
            w.delSymbol(symbol);
        }
    }

    public void placeSymbol(int wheel, String symbol) {
        Wheel rueda = this.wheels.get(wheel-1);
        rueda.place(symbol);
        wheels.set(wheel-1, rueda);
    }

    public void spin(int wheel) {
        if(wheels.get(wheel-1).isLocked() == true) {
            return;
        }
        Wheel rueda = wheels.get(wheel-1);
        rueda.Spin((int) (Math.random() * symbols.size()) + 1);
    }

    public void spin() {
        for(int i = 0; i < wheels.size();i++)
            if(wheels.get(i).isLocked() == true) {
                return;
            } else {
                Wheel rueda = wheels.get(i);
                rueda.Spin((int) (Math.random() * symbols.size()) + 1);
            }
    }
    
    public void spin(int wheel, int steps) {
        if(wheels.get(wheel-1).isLocked() == true) {
            return;
        }
        Wheel rueda = wheels.get(wheel-1);
        rueda.Spin(steps);
    }
    
    public void spin(String[] setSymbols) {
        for (int i = 0; i < setSymbols.length; i++) {
            wheels.get(i).place(setSymbols[i]);
        }
    }

    public String[] symbols() {
        String[] currentSymbols= new String[symbols.size()];
        for(int i = 0; i <  symbols.size();i++){
            currentSymbols[i] = symbols.get(i);
        }
        return currentSymbols;
    }

    public int distinctSymbols() {
        ArrayList<String> currentSymbols = new ArrayList<String>();
        String[] actualSymbols = configuration();
        for(int i = 0; i < actualSymbols.length; i++){
            currentSymbols.add(actualSymbols[i]);
        } 
        for (int i = 0; i < currentSymbols.size(); i++) {
            for (int j = i + 1; j < currentSymbols.size(); j++) {
                if (currentSymbols.get(i).equals(currentSymbols.get(j))) {
                    currentSymbols.remove(j);
                    j--;
                }
            }
        }
        return currentSymbols.size();
    }

    public String[] configuration() {
        String[] config = new String[wheels.size()];
        for (int i = 0; i < config.length; i++) {
            config[i] = wheels.get(i).getSymbol();
        }
        return config;
    }

    public boolean isJackpot() {
        if(distinctSymbols() == 1){;
        return true;
        }
        return false;
    }

    public void makeVisible() {
        isVisible = true;
        redraw();
    }

    public void makeInvisible() {
        fondo1.makeInvisible();
        fondo2.makeInvisible();
        for (Wheel w : wheels) {
            w.makeInvisible();
        }
        isVisible = false;
    }
    
    /*
     * Ubica los circulos separados SEPARACION pixeles y ajusta el tamano del
     * fondo al numero de ruedas. Si la maquina esta visible la dibuja completa:
     * primero el fondo y encima los circulos.
     */
    private void redraw() {
        int n = Math.max(wheels.size(), 1);
        int anchoBlanco = n * (Wheel.DIAMETER + SEPARACION) + SEPARACION;
        int altoBlanco = Wheel.DIAMETER + 2 * SEPARACION;
        fondo1.changeSize(altoBlanco + 2 * SEPARACION, anchoBlanco + 2 * SEPARACION);
        fondo2.changeSize(altoBlanco, anchoBlanco);
        for (int i = 0; i < wheels.size(); i++) {
            int x = 3 * SEPARACION + i * (Wheel.DIAMETER + SEPARACION);
            Wheel rueda = wheels.get(i);
            rueda.moveHorizontal(x - rueda.getX());
        }
        if (isVisible) {
            fondo1.makeVisible();
            fondo2.makeVisible();
            for (Wheel w : wheels) {
                w.makeVisible();
            }
        }
    }

    public void exit() {
    }

    public boolean ok() {
        return false;
    }
}