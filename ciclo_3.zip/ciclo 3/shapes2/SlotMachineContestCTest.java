import static org.junit.Assert.*;
import org.junit.Test;

/**
 * Pruebas compartidas del ciclo 3 (wiki).
 * Reemplacen XxYy por sus iniciales.
 *
 * @author  (RodriguezH - SarmientoM)
 * @version (ciclo 3)
 */
public class SlotMachineContestCTest
{
    @Test
    public void accordingXxYyShouldSolveTwoWheels() {
        int[][] acciones = SlotMachineContest.solve(2);
        assertTrue(acciones.length <= 11);
    }

    @Test
    public void accordingXxYyShouldNotSolveNegativeSize() {
        assertEquals(0, SlotMachineContest.solve(-3).length);
    }
}
