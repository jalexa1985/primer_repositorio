import java.util.ArrayList;
import java.util.Random;

public class Wheel{
    protected ArrayList<Wheel> wheels;
    private ArrayList<Symbol> symbols;
    private Random random;
    private boolean isVisible;
    private int position;
    private String type;
    private boolean locked;
    private Circle shape;
    
    public Wheel(ArrayList<Symbol> initialSymbols, String newType){
        this(initialSymbols);
        type = newType;
    }
    
    public Wheel(ArrayList<Symbol> initialSymbols) {
        symbols = new ArrayList<Symbol>();
        for (Symbol s : initialSymbols) {
            symbols.add(new Symbol(s.getColor(), s.type));   // cada rueda con sus propios simbolos
        }
        position = 0;
        locked = false;
        isVisible = false;
        shape = new Circle(symbols.get(position).getColor());
        shape.moveHorizontal(5);
        shape.moveVertical(5);
        type = "normal";
    }
    
    public int getPos(){
        return position;
    }
    
    public ArrayList<Symbol> getSymbols(){
        return symbols;
    }
    
    public String getSymbol(){
        return symbols.get(position).getColor();
    }
    
    public void addSymbol(int pos, String symbol){
        symbols.add(pos, new Symbol(symbol));
    }
    
    public void delSymbol(String color){
        if(position == symbols.size() - 1 && symbols.size() > 1){
            position -= 1;
        }
        for(int i = 0; i < symbols.size(); i++){
            if(symbols.get(i).getColor().equals(color)){
                symbols.remove(i);
            }
        }
               
    }
    
    public void Spin(int steps){
        int n = symbols.size();
        position = ((position + steps) % n + n) % n;
        for (Symbol s : symbols) {
            if (s.type.equals("ephemeral")) {
                s.size = Math.max(5, s.size - 10);       // se encoge hasta ser un punto
            }
        }
        Symbol actual = symbols.get(position);
        if (actual.type.equals("shy")) {
            actual.visible = !actual.visible;            // alterna cada vez que queda seleccionado
        }
        if (isVisible) {
            makeVisible();
        }
    }
    
    public void place(String color) {
        for(int i = 0; i < symbols.size(); i++)
            if(symbols.get(i).getColor().equals(color)){
                position = i;
                shape.changeColor(symbols.get(position).getColor());
            }
        
    }
    
    public String getType(){
        return type;
    }
    
    public void lock() {
        locked = true;
    }

    public void unlock() {
        locked = false;
    }
    
    public boolean isLocked() {
        return locked;
    }
    
    public void makeVisible() {
        isVisible = true;
        Symbol actual = symbols.get(position);
        shape.makeInvisible();
        shape.changeSize(actual.getSize());
        shape.changeColor(actual.getColor());
        if (actual.isVisible()) {
            shape.makeVisible();
        }
    }
    
    public void makeInvisible() {
        shape.makeInvisible();
        isVisible = false;
    }
    
    public Circle getShape() {
        return shape;
    }
}