import java.util.ArrayList;


/**
 * Write a description of class Lefty here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Lefty extends Wheel
{
    public Lefty (ArrayList<Symbol> initialSymbols, String type, ArrayList<Wheel> ruedas){
        super(initialSymbols, type);
        wheels = ruedas;                  // la misma lista de la maquina
    }
    
    @Override
    public void Spin(int steps){
        int i = wheels.indexOf(this);
        if (i > 0) {
            place(wheels.get(i - 1).getSymbol());   // copia a la rueda de su izquierda
        } else {
            super.Spin(steps);                      // si es la primera, gira normal
        }
    }
}