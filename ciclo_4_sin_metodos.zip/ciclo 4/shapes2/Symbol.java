
/**
 * Write a description of class Symbol here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Symbol {
    protected String color;
    protected int size;
    protected boolean visible;
    protected String type;

    public Symbol(String color, String newType) {
        this(color);
        type = newType;
    }
    
    public Symbol(String color) {
        this.color = color;
        size = 70;
        visible = true;
        type = "normal";
    }

    public String getColor()   {
        return color;
    }
    
    public int getSize()       {
        return size;
    }
    
    public boolean isVisible() {
        return visible;
    }

    /** Crea un simbolo del tipo dado ("normal", "ephemeral", "shy"). 
    public static Symbol create(String type, String color) {
        if (type.equals("ephemeral")){
            return new Ephemeral(color);
        }
        if (type.equals("shy")){
            return new Shy(color);
        }
        return new Symbol(color);
    }
    */
}