import static org.junit.Assert.*;
import javax.swing.JOptionPane;
import org.junit.Test;

/**
 * Pruebas de aceptacion del ciclo 4 para la presentacion (modo visible).
 * Quien mira la pantalla responde si se ve correctamente.
 *
 * @author  (RodriguezH - SarmientoM)
 * @version (ciclo 4)
 */
public class SlotMachineC4AcceptanceTest
{
    /**
     * Tipos de rueda. Orden: normal, lefty, restless, normal.
     * La lefty (rueda 2) copia el color de la rueda 1 y la restless (rueda 3)
     * se cambia de lugar con la rueda 4 cuando gira.
     */
    @Test
    public void shouldShowLeftyAndRestLess() {
        SlotMachine machine = new SlotMachine();
        machine.addSymbol(1, "red");
        machine.addSymbol(2, "blue");
        machine.addSymbol(3, "yellow");
        machine.addSymbol(4, "green");
        machine.addWheel("normal", 1);
        machine.addWheel("lefty", 2);
        machine.addWheel("normal", 3);
        machine.addWheel("saltarina", 4);           // al crearla gira y queda en la posicion 3
        machine.spin(new String[]{"red", "red", "blue", "green"});
        machine.makeVisible();
        machine.spin(1, 1);                         // rueda 1: de rojo a azul
        machine.spin(2, 1);                         // la lefty copia: azul
        JOptionPane.showMessageDialog(null, "Fijate: la rueda 4 es verde. Presiona OK para girar la rueda 3.");
        machine.spin(3, 1);                         // la restless gira y se pasa a la posicion 4
        int respuesta = JOptionPane.showConfirmDialog(null,
            "¿Las ruedas 1 y 2 son azules, y el circulo verde paso de la cuarta a la tercera posicion?");
        machine.makeInvisible();
        assertEquals(JOptionPane.YES_OPTION, respuesta);
    }

    /**
     * Tipos de simbolo: el efimero (amarillo) se encoge cada vez que la rueda
     * cae en el; el timido (azul) se esconde al quedar seleccionado.
     */
    @Test
    public void shouldShowEphemeralAndShy() {
        SlotMachine machine = new SlotMachine();
        machine.addSymbol(1, "red");
        machine.addWheel(1);
        machine.addWheel(2);
        machine.addSymbol("ephemeral", 2, "yellow");
        machine.addSymbol("shy", 3, "blue");
        machine.makeVisible();
        for (int i = 0; i < 3; i++) {
            machine.placeSymbol(1, "red");
            machine.spin(1, 1);                     // la rueda 1 cae en el efimero
        }
        machine.placeSymbol(2, "yellow");
        machine.spin(2, 1);                         // la rueda 2 cae en el timido
        int respuesta = JOptionPane.showConfirmDialog(null,
            "¿La rueda 1 muestra un circulo amarillo mas pequeno y la rueda 2 se ve vacia"
            + " (o el azul acaba de esconderse)?");
        machine.makeInvisible();
        assertEquals(JOptionPane.YES_OPTION, respuesta);
    }
}
