import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;
import org.junit.After;
/**
 * The test class SlotMachineContestCTest.
 *
 * @author  (RodriguezH - SarmientoM)
 */ 
public class SlotMachineContestCTest
{
    @Before  
    public void setUp()
    {
        int [][] pasos = SlotMachineContest.solve(3);
    }
    
    @Test
    public void shouldSimulateTheMachine(){
        SlotMachineContest.simulate(3);
    }
    
    @Test
    public void shouldNotSimulateAnEmptyMachine(){
        SlotMachineContest.simulate(0);
    }
    
    @Test
    public void shouldSolveAMachine() {
        int n = SlotMachineContest.COLORES;
        int[][] acciones = SlotMachineContest.solve(n);
        assertTrue(acciones.length <= 2 * n * n + n + 1);   // si ya salio ganadora puede ser 0
        for (int[] accion : acciones) {
            assertTrue(accion[0] >= 1 && accion[0] <= n);
            assertTrue(accion[1] >= 1);
        }
    }
    
    @Test
    public void shouldNotSolveInvalidSizes() {
        assertEquals(0, SlotMachineContest.solve(0).length);
        assertEquals(0, SlotMachineContest.solve(SlotMachineContest.COLORES + 1).length);
    }
    
    @After
    public void erase(){
        
    }
}