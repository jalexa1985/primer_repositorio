import static org.junit.Assert.*;
import javax.swing.JOptionPane;
import org.junit.Test;

/**
 * Pruebas de aceptacion del ciclo 4 para la presentacion (modo visible).
 * Quien mira la pantalla responde si se ve correctamente.
 *
 * @author  (RodriguezH - SarmientoM)
 * @version (ciclo 4)
 */
public class SlotMachineC4AcceptanceTest
{
    /**
     * Una rueda de cada tipo: normal (sin barra), lefty (barra azul y mismo
     * color que la de su izquierda), rebel (barra roja) y lazy (barra magenta).
     */
    @Test
    public void shouldShowEveryWheelType() {
        SlotMachine machine = new SlotMachine();
        machine.addSymbol(1, "red");
        machine.addSymbol(2, "blue");
        machine.addSymbol(3, "yellow");
        machine.addWheel("normal", 1);
        machine.addWheel("lefty", 2);
        machine.addWheel("rebel", 3);
        machine.addWheel("lazy", 4);
        machine.makeVisible();
        machine.spin(2, 1);
        int respuesta = JOptionPane.showConfirmDialog(null,
            "¿Ves 4 ruedas: la 1 sin barra, la 2 con barra azul y el mismo color que la 1,"
            + " la 3 con barra roja y la 4 con barra magenta?");
        machine.makeInvisible();
        assertEquals(JOptionPane.YES_OPTION, respuesta);
    }

    /**
     * Simbolo efimero (marca blanca) que se encoge en las dos ruedas a la vez,
     * y simbolo timido (marca negra) que se esconde al quedar seleccionado.
     */
    @Test
    public void shouldShowEverySymbolType() {
        SlotMachine machine = new SlotMachine();
        machine.addSymbol(1, "red");
        machine.addWheel(1);
        machine.addWheel(2);
        machine.addSymbol("ephemeral", 2, "yellow");
        machine.addSymbol("shy", 3, "blue");
        machine.makeVisible();
        for (int i = 0; i < 3; i++) {
            machine.placeSymbol(1, "red");
            machine.spin(1, 1);                 // la rueda 1 cae en el efimero
        }
        machine.placeSymbol(2, "yellow");
        machine.placeSymbol(2, "blue");         // la rueda 2 selecciona al timido: se esconde
        int respuesta = JOptionPane.showConfirmDialog(null,
            "¿La rueda 1 muestra un circulo amarillo mas pequeno y la rueda 2 quedo vacia"
            + " (el simbolo azul timido se escondio)?");
        machine.makeInvisible();
        assertEquals(JOptionPane.YES_OPTION, respuesta);
    }
}
