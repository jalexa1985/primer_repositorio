
/**
 * Simbolo normal de una rueda: tiene un color, un tamano y su circulo en pantalla.
 * Los tipos de simbolo (Ephemeral, Shy) heredan de esta clase.
 * 
 * @author (RodriguezH - SarmientoM)
 * @version (ciclo 4)
 */
public class Symbol {
    private String color;
    protected int size;
    protected boolean visible;
    private String type;
    private Circle shape;

    public Symbol(String color, String newType) {
        this(color);
        type = newType;
    }
    
    public Symbol(String color) {
        this.color = color;
        size = 70;
        type = "normal";
        visible = true;
        shape = new Circle(color);
        shape.moveHorizontal(5);
        shape.moveVertical(5);
    }

    public String getColor() {
        return color;
    }
    
    public void changeColor(String color) {
        shape.changeColor(color);
    }
    
    /**
     * Muestra el circulo, salvo que el simbolo este escondido (timido).
     */
    public void makeVisible() {
        if (visible) {
            shape.makeVisible();
        } else {
            shape.makeInvisible();
        }
    }
    
    public void makeInvisible() {
        shape.makeInvisible();
    }
    
    public String getType() {
        return type;
    }
    
    public int getSize() {
        return size;
    }
    
    /**
     * Encoge el simbolo. Un simbolo normal no cambia de tamano.
     */
    public void changeSize() {
    }
    
    /**
     * Avisa que el simbolo quedo como el visible de la rueda.
     * Un simbolo normal no cambia.
     */
    public void selected() {
    }
    
    /**
     * Color de la marca que identifica el tipo de simbolo en pantalla.
     * @return null si no lleva marca (simbolo normal)
     */
    public String markColor() {
        return null;
    }
    
    public Circle getShape() {
        return shape;
    }
    
    public boolean isVisible() {
        return visible;
    }
    
    /**
     * Crea un simbolo nuevo del mismo tipo y color, con su propio circulo.
     */
    public Symbol copy() {
        return new Symbol(color, type);
    }
}
