import java.util.ArrayList;


/**
 * Rueda lefty: si hay una rueda a su izquierda, al girar copia su simbolo.
 * Si es la primera rueda, gira normal.
 * 
 * @author (RodriguezH - SarmientoM)
 * @version (ciclo 4)
 */
public class Lefty extends Wheel
{
    public Lefty (ArrayList<Symbol> initialSymbols, String type, ArrayList<Wheel> ruedas){
        super(initialSymbols, type);
        wheels = ruedas;
    }
    
    @Override
    public void Spin(int steps){
        int i = wheels.indexOf(this);
        if (i > 0) {
            place(wheels.get(i-1).getSymbol());
        } else {
            super.Spin(steps);
        }
    }
    
    @Override
    public String markColor() {
        return "blue";
    }
}