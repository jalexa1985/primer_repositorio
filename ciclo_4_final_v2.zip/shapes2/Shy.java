
/**
 * Simbolo timido: cada vez que queda seleccionado en una rueda
 * alterna entre visible e invisible.
 * 
 * @author (RodriguezH - SarmientoM)
 * @version (ciclo 4)
 */
public class Shy extends Symbol
{
    public Shy (String color, String type){
        super(color, type);
    }
    
    /**
     * Cada vez que queda seleccionado cambia su visibilidad.
     */
    @Override
    public void selected() {
        visible = !visible;
    }
    
    @Override
    public String markColor() {
        return "black";
    }
    
    @Override
    public Symbol copy() {
        return new Shy(getColor(), getType());
    }
}
