
/**
 * Simbolo efimero: cada vez que una rueda cae en el, se hace mas pequeno
 * (en todas las ruedas a la vez) hasta quedar como un punto.
 * 
 * @author (RodriguezH - SarmientoM)
 * @version (ciclo 4)
 */
public class Ephemeral extends Symbol
{
    public static final int MINIMO = 5;
    public static final int REDUCCION = 10;
    
    public Ephemeral (String color, String type){
        super(color, type);
    }
    
    /**
     * Se reduce sin bajar de MINIMO y se mantiene centrado.
     */
    @Override
    public void changeSize() {
        int antes = size;
        size = Math.max(MINIMO, size - REDUCCION);
        getShape().changeSize(size);
        getShape().moveVertical((antes - size) / 2);   // baja la mitad de lo que se encogio
    }
    
    /**
     * La copia queda del mismo tamano que este simbolo.
     */
    @Override
    public Symbol copy() {
        Ephemeral nuevo = new Ephemeral(getColor(), getType());
        while (nuevo.getSize() > getSize()) {
            nuevo.changeSize();
        }
        return nuevo;
    }
    
    @Override
    public String markColor() {
        return "white";
    }
}
