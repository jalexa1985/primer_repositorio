import java.util.ArrayList;
import java.util.Random;

/**
 * Simulador de la maquina tragamonedas (ciclos 1 a 4).
 *
 * @author (RodriguezH - SarmientoM)
 * @version (ciclo 4)
 */
public class SlotMachine {
    private ArrayList<Wheel> wheels;
    private ArrayList<Symbol> symbols;
    private boolean isVisible;
    private Rectangle fondo1;
    private Rectangle fondo2;
    private int posicion;
    private ArrayList<Rectangle> barras;    // barra de color bajo cada rueda especial
    private ArrayList<Triangle> marcas;     // marca sobre los simbolos especiales
    
    public SlotMachine() {
        wheels = new ArrayList<Wheel>();
        symbols = new ArrayList<Symbol>();
        isVisible = false;
        posicion = 0;
        barras = new ArrayList<Rectangle>();
        marcas = new ArrayList<Triangle>();
        fondo1 = new Rectangle();
        fondo2 = new Rectangle();
        fondo2.changeSize(80, 80);
        fondo2.moveHorizontal(10);
        fondo2.moveVertical(10);
        fondo2.changeColor("white");
    }
    
    public SlotMachine(int n) {
        wheels = new ArrayList<Wheel>();
        symbols = new ArrayList<Symbol>();
        posicion = 0;
        barras = new ArrayList<Rectangle>();
        marcas = new ArrayList<Triangle>();
        fondo1 = new Rectangle();
        fondo2 = new Rectangle();
        fondo2.changeSize(80, 80);
        fondo2.moveHorizontal(10);
        fondo2.moveVertical(10);
        fondo2.changeColor("white");
        String[] colores = {"red", "green", "yellow", "blue", "magenta"};
        for(int i = 0; i < n; i++){
            addSymbol(i + 1, colores[i]);
        }
        
        for(int i = 0; i < n; i++){
            addWheel(i);
        }
        actualizar();
    }
    
    public void addWheel(int pos) {
        if (symbols.size() < 1){
            System.out.println("no se puede añadir una rueda sin simbolos");
            actualizar();
        } else {
            if (pos < 1) {
                pos = 1;
            }
            
            if (pos > wheels.size() + 1) {
                pos = wheels.size() + 1;
            }
            wheels.add(pos - 1, new Wheel(symbols));
            spin(pos);
            actualizar();
        }
    }
    
    public void addWheel(String type, int pos) {
        if (symbols.size() < 1){
            System.out.println("no se puede añadir una rueda sin simbolos");
            actualizar();
        } else {
            if (pos < 1) {
                pos = 1;
            }
            if (pos > wheels.size() + 1) {
                pos = wheels.size() + 1;
            }
            Wheel rueda = null;
            if (type.equals("normal")){
                rueda = new Wheel(symbols);
            } else if (type.equals("lefty")){
                rueda = new Lefty(symbols, type, wheels);
            } else if (type.equals("rebel")){
                rueda = new Rebel(symbols, type);
            } else if (type.equals("lazy")){
                rueda = new Lazy(symbols, type);
            } else {
                System.out.println("tipo de rueda desconocido: " + type);
                return;
            }
            wheels.add(pos - 1, rueda);
            spin(pos);
            actualizar();
        }
    }
    
    public void delWheel(int pos) {
        if(pos > wheels.size() && pos < 0){
            System.out.println("Maximo posicion" + wheels.size() + "y minimo posicion 1");
        }else{
            if (!wheels.get(pos - 1).canDelete()) {
                return;
            }
            wheels.get(pos - 1).makeInvisible();
            wheels.remove(pos-1);
        }
        actualizar();
    }
    
    public void swap(int wheel1, int wheel2) {
        if(wheel1 == wheel2){
            return;
        }
        if (!wheels.get(wheel1 - 1).canSwap() || !wheels.get(wheel2 - 1).canSwap()) {
            return;
        }
        Wheel auxiliar = wheels.get(wheel1 - 1);
        wheels.set(wheel1 - 1, wheels.get(wheel2 - 1));
        wheels.set(wheel2 - 1, auxiliar);
        actualizar();
    }
    
    public void lock(int wheel) {
        Wheel rueda = wheels.get(wheel-1);
        if (!rueda.canLock()) {
            return;
        }
        rueda.lock();
        wheels.set(wheel-1, rueda);
    }
    
    public void unlook(int wheel) {
        Wheel rueda = wheels.get(wheel-1);
        rueda.unlock();
        wheels.set(wheel-1, rueda);
    }
    
    public void addSymbol(int pos, String color) {
        for(int i = 0; i < symbols.size(); i++){
            if (symbols.get(i).getColor().equals(color)){
                System.out.println("el symbolo ya esta en la maquina");
                return;
            }
        }
        symbols.add(pos - 1, new Symbol(color));
        for (Wheel w : wheels) {
            w.addSymbol(pos - 1, color);
        }
    }
    
    public void addSymbol(String type, int pos, String color) {
        for(int i = 0; i < symbols.size(); i++){
            if (symbols.get(i).getColor().equals(color)){
                System.out.println("el symbolo ya esta en la maquina");
                return;
            }
        }
        Symbol simbolo = null;
            if (type.equals("normal")){
                simbolo = new Symbol(color);
            } else if (type.equals("shy")){
                simbolo = new Shy(color, type);
            } else if (type.equals("ephemeral")){
                simbolo = new Ephemeral(color, type);
            }
        if (simbolo == null) {
            System.out.println("tipo de simbolo desconocido: " + type);
            return;
        }
        symbols.add(pos - 1, simbolo);
        for (Wheel w : wheels) {
            w.getSymbols().add(pos - 1, simbolo.copy());   // cada rueda con su propia copia
        }
        actualizar();
    }

    public void delSymbol(String symbol) {
        for (Wheel w : wheels) {
            w.delSymbol(symbol);
        }
        for (int i = 0; i < symbols.size(); i++) {
            if (symbols.get(i).getColor().equals(symbol)) {
                symbols.remove(i);
            }
        }
        actualizar();
    }

    public void placeSymbol(int wheel, String symbol) {
        wheels.get(wheel-1).place(symbol);       
        actualizar();
    }

    public void spin(int wheel) {
        if(wheels.get(wheel-1).isLocked() == true) {
            return;
        }
        pausarPintado();
        Wheel rueda = wheels.get(wheel-1);
        rueda.Spin((int) (Math.random() * symbols.size()) + 1);
        encogerEfimero(rueda);
        actualizar();
        reanudarPintado();
    }

    public void spin() {
        pausarPintado();
        for(int i = 0; i < wheels.size();i++){
            if(wheels.get(i).isLocked() == true) {
                continue;
            } else {
                Wheel rueda = wheels.get(i);
                rueda.Spin((int) (Math.random() * symbols.size()) + 1);
                encogerEfimero(rueda);
            }
        }
        actualizar();
        reanudarPintado();
    }

    public void spin(int wheel, int steps) {
        if(wheels.get(wheel-1).isLocked() == true) {
            return;
        }
        Wheel rueda = wheels.get(wheel-1);
        for (int i = 0; i < steps;i++){
            pausarPintado();
            rueda.Spin(1);
            encogerEfimero(rueda);
            actualizar();
            reanudarPintado();
        }
    }
    
    public void spin(String[] setSymbols) {
        for (int i = 0; i < setSymbols.length; i++) {
            wheels.get(i).place(setSymbols[i]);
        }
        actualizar();
    }

    public String[] symbols() {
        String[] currentSymbols = new String[symbols.size()];
        for(int i = 0; i <  symbols.size(); i++){
            currentSymbols[i] = symbols.get(i).getColor();
        }
        return currentSymbols;
    }

    public int distinctSymbols() {
        ArrayList<String> currentSymbols = new ArrayList<String>();
        String[] actualSymbols = configuration();
        for(int i = 0; i < actualSymbols.length; i++){
            currentSymbols.add(actualSymbols[i]);
        } 
        for (int i = 0; i < currentSymbols.size(); i++) {
            for (int j = i + 1; j < currentSymbols.size(); j++) {
                if (currentSymbols.get(i).equals(currentSymbols.get(j))) {
                    currentSymbols.remove(j);
                    j--;
                }
            }
        }
        return currentSymbols.size();
    }

    public String[] configuration() {
        String[] config = new String[wheels.size()];
        for (int i = 0; i < config.length; i++) {
            config[i] = wheels.get(i).getSymbol();
        }
        return config;
    }

    public boolean isJackpot() {
        if(distinctSymbols() == 1){
            return true;
        } else {
            return false;
        }
    }

    public void makeVisible() {
        fondo1.makeVisible();
        fondo2.makeVisible();
        for(Wheel w: wheels){
            w.makeVisible();
        }
        for (Rectangle b : barras) {
            b.makeVisible();
        }
        for (Triangle t : marcas) {
            t.makeVisible();
        }
        isVisible = true;
    }

    public void makeInvisible() {
        fondo1.makeInvisible();
        fondo2.makeInvisible();
        for(Wheel w: wheels){
            w.makeInvisible();
        }
        borrarMarcas();
        isVisible = false;
    }

    public void exit() {
        makeInvisible();
    }

    public boolean ok() {
        return true;
    }
    
    public ArrayList<Wheel> getWheels(){
        return wheels;
    }
    
    public void actualizar() {
        pausarPintado();
        int n = Math.max(wheels.size(), 1);
        int anchoFondo1 = n * 100;
        fondo1.changeSize(100, anchoFondo1);
        fondo2.changeSize(80, anchoFondo1 - 20);
        borrarMarcas();
        for (int i = 0; i < wheels.size(); i++) {
            posicion = i * 100;
            Wheel rueda = wheels.get(i);
            Symbol actual = rueda.getVisibleSymbol();
            int margen = (70 - actual.getSize()) / 2;            // centra los circulos mas pequenos
            rueda.getShape().moveHorizontalTo(posicion + margen);
            if (rueda.markColor() != null) {
                Rectangle barra = new Rectangle();               // nace en (10, 10)
                barra.changeSize(8, 70);
                barra.moveHorizontal(15 + posicion);             // debajo del circulo
                barra.moveVertical(91);                          // sobre el borde de la maquina
                barra.changeColor(rueda.markColor());
                barras.add(barra);
            }
            if (actual.markColor() != null && actual.isVisible() && actual.getSize() >= 30) {
                Triangle marca = new Triangle();                 // nace en (140, 15)
                marca.changeSize(14, 16);
                marca.moveHorizontal(60 + posicion - 140);       // centro del circulo
                marca.moveVertical(25 + margen + 3 - 15);        // parte de arriba del circulo
                marca.changeColor(actual.markColor());
                marcas.add(marca);
            }
        }
        if(isVisible){
            if (isJackpot() == true || distinctSymbols() == 1) {
                fondo1.changeColor("green");
            } else {
                fondo1.changeColor("black");
            }
            makeVisible();
        }
        reanudarPintado();
    }
    
    /*
     * Si la rueda quedo mostrando un simbolo efimero, ese simbolo (mismo color)
     * se encoge al mismo tiempo en todas las ruedas y en la maquina.
     */
    private void encogerEfimero(Wheel rueda) {
        Symbol actual = rueda.getVisibleSymbol();
        if (!actual.getType().equals("ephemeral")) {
            return;
        }
        String color = actual.getColor();
        for (Wheel w : wheels) {
            for (Symbol s : w.getSymbols()) {
                if (s.getColor().equals(color)) {
                    s.changeSize();
                }
            }
        }
        for (Symbol s : symbols) {
            if (s.getColor().equals(color)) {
                s.changeSize();
            }
        }
    }
    
    /*
     * Borra de la pantalla las barras y marcas de los tipos.
     */
    private void borrarMarcas() {
        for (Rectangle b : barras) {
            b.makeInvisible();
        }
        for (Triangle t : marcas) {
            t.makeInvisible();
        }
        barras.clear();
        marcas.clear();
    }
    
    /*
     * Mientras la maquina esta visible, deja de pintar la ventana para que los
     * cambios se vean todos juntos (sin parpadeo).
     */
    private void pausarPintado() {
        if (isVisible) {
            Canvas.getCanvas().pausar();
        }
    }
    
    /*
     * Pinta la ventana una vez con todos los cambios.
     */
    private void reanudarPintado() {
        if (isVisible) {
            Canvas.getCanvas().reanudar();
        }
    }
}
