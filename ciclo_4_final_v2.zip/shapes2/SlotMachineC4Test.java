import static org.junit.Assert.*;
import java.util.ArrayList;
import org.junit.Before;
import org.junit.Test;

/**
 * Pruebas de unidad del ciclo 4: tipos de ruedas y de simbolos (modo invisible).
 * Como addWheel gira la rueda al azar, las pruebas comparan antes y despues.
 *
 * @author  (RodriguezH - SarmientoM)
 * @version (ciclo 4)
 */
public class SlotMachineC4Test
{
    private SlotMachine machine;
    private ArrayList<Symbol> simbolos;

    @Before
    public void setUp() {
        machine = new SlotMachine();
        machine.addSymbol(1, "red");
        machine.addSymbol(2, "green");
        machine.addSymbol(3, "yellow");
        simbolos = new ArrayList<Symbol>();
        simbolos.add(new Symbol("red"));
        simbolos.add(new Symbol("green"));
        simbolos.add(new Symbol("yellow"));
    }

    // ---------------- tipos de rueda ----------------

    @Test
    public void shouldAddWheelsOfEveryType() {
        machine.addWheel("normal", 1);
        machine.addWheel("lefty", 2);
        machine.addWheel("rebel", 3);
        machine.addWheel("lazy", 4);
        assertEquals(4, machine.configuration().length);
        assertTrue(machine.getWheels().get(1) instanceof Lefty);
        assertTrue(machine.getWheels().get(2) instanceof Rebel);
        assertTrue(machine.getWheels().get(3) instanceof Lazy);
    }

    @Test
    public void shouldNotAddWheelOfUnknownType() {
        machine.addWheel("crazy", 1);
        assertEquals(0, machine.configuration().length);
    }

    @Test
    public void shouldKeepTheWheelType() {
        machine.addWheel("rebel", 1);
        assertEquals("rebel", machine.getWheels().get(0).getType());
    }

    // ---------------- rebel ----------------

    @Test
    public void shouldNotLockRebel() {
        machine.addWheel("rebel", 1);
        machine.lock(1);
        assertFalse(machine.getWheels().get(0).isLocked());
    }

    @Test
    public void shouldLockNormalWheel() {
        machine.addWheel("normal", 1);
        machine.lock(1);
        assertTrue(machine.getWheels().get(0).isLocked());
    }

    @Test
    public void shouldNotDeleteRebel() {
        machine.addWheel("normal", 1);
        machine.addWheel("rebel", 2);
        machine.delWheel(2);
        assertEquals(2, machine.configuration().length);
    }

    @Test
    public void shouldNotSwapRebel() {
        machine.addWheel("normal", 1);
        machine.addWheel("rebel", 2);
        Wheel primera = machine.getWheels().get(0);
        machine.swap(1, 2);
        assertSame(primera, machine.getWheels().get(0));
    }

    // ---------------- lefty ----------------

    @Test
    public void shouldCopyLeftWheelWhenLeftySpins() {
        machine.addWheel("normal", 1);
        machine.addWheel("lefty", 2);
        for (int i = 0; i < 10; i++) {
            machine.spin(1);
            machine.spin(2, 1);
            assertEquals(machine.configuration()[0], machine.configuration()[1]);
        }
    }

    @Test
    public void shouldSpinNormallyWhenLeftyIsFirst() {
        machine.addWheel("lefty", 1);
        String antes = machine.configuration()[0];
        machine.spin(1, 1);
        assertNotEquals(antes, machine.configuration()[0]);
    }

    // ---------------- lazy (propuesto) ----------------

    @Test
    public void shouldMoveLazyHalfTheSteps() {
        Wheel lazy = new Lazy(simbolos, "lazy");
        lazy.Spin(4);
        assertEquals(2, lazy.getPos());
    }

    @Test
    public void shouldNotMoveLazyWithOneStep() {
        Wheel lazy = new Lazy(simbolos, "lazy");
        lazy.Spin(1);
        assertEquals(0, lazy.getPos());
        lazy.Spin(1);                       // con el paso guardado ya avanza
        assertEquals(1, lazy.getPos());
    }

    // ---------------- simbolos ----------------

    @Test
    public void shouldNotAddSymbolOfUnknownType() {
        machine.addSymbol("crazy", 4, "blue");
        assertEquals(3, machine.symbols().length);
    }

    @Test
    public void shouldGiveEachWheelItsOwnSymbols() {
        machine.addWheel(1);
        machine.addWheel(2);
        machine.addSymbol("ephemeral", 4, "blue");          // despues de crear las ruedas
        Symbol enRueda1 = machine.getWheels().get(0).getSymbols().get(3);
        Symbol enRueda2 = machine.getWheels().get(1).getSymbols().get(3);
        assertNotSame(enRueda1, enRueda2);
        assertTrue(enRueda1 instanceof Ephemeral);
    }

    @Test
    public void shouldDeleteSymbolFromTheMachine() {
        machine.delSymbol("green");
        assertEquals(2, machine.symbols().length);
    }

    // ---------------- ephemeral ----------------

    @Test
    public void shouldShrinkEphemeralInEveryWheel() {
        machine.addWheel(1);
        machine.addWheel(2);
        machine.addSymbol("ephemeral", 4, "blue");
        int antes = machine.getWheels().get(1).getSymbols().get(3).getSize();
        machine.placeSymbol(1, "yellow");
        machine.spin(1, 1);                                // solo la rueda 1 cae en blue
        assertEquals("blue", machine.configuration()[0]);
        assertEquals(antes - Ephemeral.REDUCCION, machine.getWheels().get(0).getSymbols().get(3).getSize());
        assertEquals(antes - Ephemeral.REDUCCION, machine.getWheels().get(1).getSymbols().get(3).getSize());
    }

    @Test
    public void shouldNotShrinkEphemeralBelowAPoint() {
        Symbol e = new Ephemeral("blue", "ephemeral");
        for (int i = 0; i < 50; i++) {
            e.changeSize();
        }
        assertEquals(Ephemeral.MINIMO, e.getSize());
    }

    @Test
    public void shouldNotShrinkNormalSymbol() {
        machine.addWheel(1);
        for (int i = 0; i < 6; i++) {
            machine.spin(1, 1);
        }
        assertEquals(70, machine.getWheels().get(0).getSymbols().get(0).getSize());
    }

    // ---------------- shy ----------------

    @Test
    public void shouldHideShyWhenSelected() {
        simbolos.add(1, new Shy("blue", "shy"));
        Wheel w = new Wheel(simbolos);
        w.Spin(1);
        assertFalse(w.getVisibleSymbol().isVisible());
    }

    @Test
    public void shouldShowShyWhenSelectedAgain() {
        simbolos.add(1, new Shy("blue", "shy"));
        Wheel w = new Wheel(simbolos);
        w.Spin(1);
        w.Spin(4);                          // da la vuelta y vuelve a quedar seleccionado
        assertTrue(w.getVisibleSymbol().isVisible());
    }

    @Test
    public void shouldNotRemoveShyFromConfiguration() {
        machine.addSymbol("shy", 4, "blue");
        machine.addWheel(1);
        machine.placeSymbol(1, "blue");
        assertEquals("blue", machine.configuration()[0]);
    }
}
