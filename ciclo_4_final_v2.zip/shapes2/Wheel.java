import java.util.ArrayList;
import java.util.Random;

/**
 * Rueda normal de la maquina. Tiene sus propios simbolos y muestra el de su
 * posicion actual. Los tipos de rueda (Lefty, Rebel, Lazy) heredan de esta clase.
 *
 * @author (RodriguezH - SarmientoM)
 * @version (ciclo 4)
 */
public class Wheel{
    protected ArrayList<Wheel> wheels;
    private ArrayList<Symbol> symbols;
    private Random random;
    private boolean isVisible;
    private int position;
    private String type;
    private boolean locked;
    
    public Wheel(ArrayList<Symbol> initialSymbols, String newType){
        this(initialSymbols);
        type = newType;
    }
    
    public Wheel(ArrayList<Symbol> initialSymbols) {
        position = 0;
        locked = false;
        isVisible = false;
        type = "normal";
        symbols = new ArrayList<Symbol>();
        for (Symbol s : initialSymbols) {
            symbols.add(s.copy());          // cada rueda con sus propios simbolos
        }
    }
    
    public int getPos(){
        return position;
    }
    
    public ArrayList<Symbol> getSymbols(){
        return symbols;
    }
    
    public String getSymbol(){
        return symbols.get(position).getColor();
    }
    
    public void addSymbol(int pos, String symbol){
        symbols.add(pos, new Symbol(symbol));
    }
    
    public void delSymbol(String color){
        if(position == symbols.size() - 1 && symbols.size() > 1){
            position -= 1;
        }
        for(int i = 0; i < symbols.size(); i++){
            if(symbols.get(i).getColor().equals(color)){
                symbols.get(i).makeInvisible();
                symbols.remove(i);
            }
        }
    }
    
    /**
     * Gira la rueda. El simbolo que deja de verse se esconde y el nuevo
     * queda seleccionado (el timido cambia su visibilidad).
     * El efimero lo encoge SlotMachine, en todas las ruedas a la vez.
     */
    public void Spin(int steps){
        symbols.get(position).makeInvisible();
        int n = symbols.size();
        position = ((position + steps) % n + n) % n;
        symbols.get(position).selected();
        symbols.get(position).changeColor(symbols.get(position).getColor());
    }
    
    public void place(String color) {
        for(int i = 0; i < symbols.size(); i++) {
            if(symbols.get(i).getColor().equals(color)){
                symbols.get(position).makeInvisible();
                position = i;
                symbols.get(position).selected();
                symbols.get(position).changeColor(symbols.get(position).getColor());
                return;
            }
        }
    }
    
    public String getType(){
        return type;
    }
    
    public void lock() {
        locked = true;
    }

    public void unlock() {
        locked = false;
    }
    
    public boolean isLocked() {
        return locked;
    }
    
    public void makeVisible() {
        symbols.get(position).changeColor(symbols.get(position).getColor());
        symbols.get(position).makeVisible();
        isVisible = true;
    }
    
    public void makeInvisible() {
        symbols.get(position).makeInvisible();
        isVisible = false;
    }
    
    public boolean canLock() {
        return true;
    }

    public boolean canSwap() {
        return true;
    }

    public boolean canDelete() {
        return true;
    }

    public Circle getShape() {
        return symbols.get(position).getShape();
    }
    
    /**
     * Retorna el simbolo que la rueda esta mostrando.
     */
    public Symbol getVisibleSymbol() {
        return symbols.get(position);
    }
    
    /**
     * Color de la barra que identifica el tipo de rueda en pantalla.
     * @return null si no lleva barra (rueda normal)
     */
    public String markColor() {
        return null;
    }
    
    
}